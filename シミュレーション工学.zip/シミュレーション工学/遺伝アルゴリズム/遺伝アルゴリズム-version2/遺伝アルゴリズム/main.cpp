//
//  main.cpp
//  遺伝アルゴリズム
//
//  Created by 姜玮航 on 2021/12/22.
//

#include <iostream>
#include <stdio.h>

using namespace std;

const int item_num = 20;            //物品数量
const int weight_max = 500;        //最大重量
const int maxn = 10;            //种群数量
const double d = 0.1;              //常数（用于惩罚）
const double pc = 0.85;            //交叉概率
const double pm = 0.06;            //变异概率
const int iteration = 500;

int sum = 0;

typedef struct population
{
    int item[item_num];
    int value;
    int weight;
    double fit;
}pop;

int wei[item_num] = {8,6,2,3,5,3,4,3,4,5,5,2,5,5,2,5,3,5,8,4};
int val[item_num] = {12, 18, 29, 25, 1, 22, 13, 11, 6, 16, 5, 9, 19, 13, 10, 15, 10, 3, 19, 31};

int index1 = 0;
int quanju_best_value = 0;
int quanju_best_weight = 0;
int quanju_best_fitness = 0;
int arr[item_num];


void Init_population(pop p[])
{
    for(int i = 0; i < maxn; i++)
    {
        for(int j = 0; j < item_num; j++)
        {
            p[i].item[j] = rand() % 2;
            printf("%d",p[i].item[j]);
        }
        printf("\n");
    }
}

//适应度函数
void fitness(pop p[])
{
    for(int i = 0; i < maxn; i++)
    {
        int value_sum = 0, weight_sum = 0;
        for(int j = 0; j < item_num; j++)
        {
            if(p[i].item[j] == 1)
            {
                value_sum += val[j];
                weight_sum += wei[j];
            }
        }
        p[i].value = value_sum;
        p[i].weight = weight_sum;
        /*
        如果该个体重量小于等于100，则其适应度函数为该个体方案的价值，并未改变；
        而如果该个体重量超过100，则让其适应度fit = value_sum * d;其中，d是很小的数，且d < 0,
        即降低其适应度，那么在后面进行选择时，它被选择的概率就变的很小，即实现惩罚目的。
        */
        if(weight_sum <= weight_max)
        {
            p[i].fit = value_sum;
        }
        else        //惩罚
        {
            p[i].fit = value_sum * d;
        }
    }
}

bool cmp(pop a, pop b){
    if(a.fit > b.fit) return true;
    else return false;
}

//选择
void Select(pop p[])
{
    int i;
    double choice_pro[maxn];        //每个个体选择机会
    double sum_fit = 0;                //总适应度
    double average_fit = 0;            //平均适应度
    for(int i = 0; i < maxn; i++)
        sum_fit += p[i].fit;
    sort(p, p + maxn, cmp);
    average_fit = (unsigned int)((sum_fit / maxn) + 0.5);    //计算出平均适应值
    for (i = 0; i < maxn; i++)    //计算每个群体的选择机会
    {
        //种群个体的概率 = 个体适应度/总适应度 平均概率 = 平均适应度/总适应度 个体被选择机会 = (个体的概率/平均概率)
        choice_pro[i] = ((double)p[i].fit / sum_fit) / (average_fit / sum_fit);
        choice_pro[i] = (double)((int)(choice_pro[i] * 100 + 0.5) / 100.0);//保留到小数点后2位,四舍五入
    }
    //根据选择概率来繁殖(copy)优良个体、淘汰较差个体 如果choicePro[i]==0淘汰复制一次最优的群体
    for (i = 0; i < maxn; i++)
    {
        if (((int)(choice_pro[i] + 0.55)) == 0)
            p[maxn - 1] = p[0];
    }
}

//交叉
void Crossover(pop p[])
{
    int n = maxn;
    while(n--)
    {
        int num = rand() % 100;
        if(num <= pc * 100){
        int ia = 0, ib = 0;
        while(ia == ib)
        {
            ia = rand() % maxn;
            ib = rand() % maxn;
        }
        int a = 0, b = 0;
        while(a == b || a > b)
        {
            a = rand() % item_num;
            b = rand() % item_num;
        }
        for(int i = a; i < b; i++)
        {
            int temp = p[ia].item[i];
            p[ia].item[i] = p[ib].item[i];
            p[ib].item[i] = temp;
        }
    }
    }
}

//变异
void Mutation(pop p[])
{
    for(int i = 0; i < maxn; i++){
        int a = rand() % 100;
        if(a <= pm * 100){
        int b = rand() % item_num;
        if(p[i].item[b] == 1)
            p[i].item[b] = 0;
        else
            p[i].item[b] = 1;
        }
    }
}


int main()
{
    pop p[maxn];
    memset(arr, 0, sizeof(arr));
    srand((unsigned)time(NULL));
    Init_population(p);
    int cnt = 0;
    while(cnt < iteration)
    {
        fitness(p);
        int jubu_best_value = 0;
        int jubu_best_weight = 0;
        int jubu_best_index = 0;
        double jubu_best_fitness = 0;
        for(int i = 0; i < maxn; i++)
            if(p[i].fit > jubu_best_fitness)
            {
                jubu_best_fitness = p[i].fit;
                jubu_best_value = p[i].value;
                jubu_best_weight = p[i].weight;
                jubu_best_index = i;
            }
        if(jubu_best_value == quanju_best_value) sum++;
        for(int i = 0; i < item_num; i++)
            if(p[jubu_best_index].item[i] == 1)
            {
                cout<<i<<" ";
            }
        if(jubu_best_fitness > quanju_best_fitness)
        {
            index1 = cnt + 1;
            quanju_best_fitness = jubu_best_fitness;
            quanju_best_value = jubu_best_value;
            quanju_best_weight = jubu_best_weight;
            for(int i = 0; i < item_num; i++)
                arr[i] = p[jubu_best_index].item[i];
        }
        cout<<endl;
        Select(p);
        Crossover(p);
        Mutation(p);
        cnt++;
    }
    cout<<"全局最优解为："<<endl;
    cout<<"价值："<<quanju_best_value<<"，重量："<<quanju_best_weight<<endl;
    cout<<"方案：";
    for(int i = 0; i < item_num; i++)
        if(arr[i] == 1)
            cout<<i + 1<<" ";
    cout<<endl;
    cout<<"最优解在第"<<index1<<"代产生"<<endl;
    cout<<"迭代次数为："<<iteration<<", 最优解次数为："<<sum<<"，收敛率为："<<((double)sum / iteration) * 100<<"%"<<endl;
}
